/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       C:\Users\School                                           */
/*    Created:      Wed Oct 25 2023                                           */
/*    Description:  V5 project                                                */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// RMot18               motor         11              
// RMot19               motor         12              
// RMot20               motor         13              
// LMot7                motor         20              
// LMot8                motor         19              
// LMot9                motor         18              
// Controller1          controller                    
// IntMot16             motor         16              
// LaunchMot15          motor         15              
// Pneu                 digital_out   H               
// PneuB                digital_out   G               
// PneuX                digital_out   D               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

competition Competition;
// "when started" hat block
int pneuVarA = 0;
int pneuVarB = 0;
int pneuVarX = 0;

void setSpeed() { while (true){
  int forVar = Controller1.Axis3.position(percent);
  float turnVar = Controller1.Axis1.position(percent);
  int rmVar = 0;
  int lmVar = 0;

if (forVar < 5 && forVar > -5) {forVar = (0);}

if (forVar < 0) {
 rmVar = (forVar + turnVar);
 lmVar = (forVar - turnVar);
 if (lmVar > 0){lmVar = 0;}
 if (rmVar > 0){rmVar = 0;}

} else if (forVar > 0){
  rmVar = (forVar - turnVar);
  lmVar = (forVar + turnVar);
  if (rmVar < 0){rmVar = 0;}
  if (lmVar < 0){lmVar = 0;}
} else {
  rmVar = (-turnVar);
  lmVar = (turnVar);
}

if (Controller1.ButtonL1.pressing()) {
  IntMot16.spin(forward, 100, percent); 
} else if (Controller1.ButtonR1.pressing()) {
  IntMot16.spin(reverse, 100, percent);
} else {
 IntMot16.spin(forward, 0, percent);
}

if (Controller1.ButtonA.pressing() && pneuVarA == 0){
  Pneu.set(true);
  wait(0.5, seconds);
  pneuVarA = 1;
}

if (Controller1.ButtonA.pressing() && pneuVarA == 1){
  Pneu.set(false);
  wait(0.5, seconds);
  pneuVarA = 0;
}

if (Controller1.ButtonB.pressing() && pneuVarB == 0){
  PneuB.set(true);
  wait(0.5, seconds);
  pneuVarB = 1;
}

if (Controller1.ButtonB.pressing() && pneuVarB == 1){
  PneuB.set(false);
  wait(0.5, seconds);
  pneuVarB = 0;
}

if (Controller1.ButtonX.pressing() && pneuVarX == 0){
  PneuX.set(true);
  wait(0.5, seconds);
  pneuVarX = 1;
}

if (Controller1.ButtonX.pressing() && pneuVarX == 1){
  PneuX.set(false);
  wait(0.5, seconds);
  pneuVarX = 0;
}



if (Controller1.ButtonR2.pressing()) {
  LaunchMot15.setVelocity(75, percent);
  LaunchMot15.spin(forward); 
} else {
  LaunchMot15.setVelocity(0, percent);
  LaunchMot15.spin(forward);
}

  RMot18.setVelocity(rmVar, percent);
  RMot19.setVelocity(rmVar, percent);
  RMot20.setVelocity(rmVar, percent);
  LMot7.setVelocity(lmVar, percent);
  LMot8.setVelocity(lmVar, percent);
  LMot9.setVelocity(lmVar, percent);
  RMot18.spin(forward);
  RMot19.spin(forward);
  RMot20.spin(forward);
  LMot7.spin(forward);
  LMot8.spin(forward);
  LMot9.spin(forward);
}}

void RM30(){
  RMot18.spin(forward, 30, percent);
  RMot19.spin(forward, 30, percent);
  RMot20.spin(forward, 30, percent);
}

void RM15(){
  RMot18.spin(forward, 15, percent);
  RMot19.spin(forward, 15, percent);
  RMot20.spin(forward, 15, percent);
}

void RM100(){
  RMot18.spin(forward, 100, percent);
  RMot19.spin(forward, 100, percent);
  RMot20.spin(forward, 100, percent);
}

void RM_15(){
  RMot18.spin(forward, -15, percent);
  RMot19.spin(forward, -15, percent);
  RMot20.spin(forward, -15, percent);
}

void RM0(){
  RMot18.spin(forward, 0, percent);
  RMot19.spin(forward, 0, percent);
  RMot20.spin(forward, 0, percent);
}

void LM30(){
  LMot7.spin(forward, 30, percent);
  LMot8.spin(forward, 30, percent);
  LMot9.spin(forward, 30, percent);
}

void LM100(){
  LMot7.spin(forward, 100, percent);
  LMot8.spin(forward, 100, percent);
  LMot9.spin(forward, 100, percent);
}

void LM15(){
  LMot7.spin(forward, 15, percent);
  LMot8.spin(forward, 15, percent);
  LMot9.spin(forward, 15, percent);
}

void LM_15(){
  LMot7.spin(forward, -15, percent);
  LMot8.spin(forward, -15, percent);
  LMot9.spin(forward, -15, percent);
}

void LM0(){
  LMot7.spin(forward, 0, percent);
  LMot8.spin(forward, 0, percent);
  LMot9.spin(forward, 0, percent);
}

void Autonomous(){
  wait(1, seconds);
  //outtake
  IntMot16.spin(reverse, 10, percent);
  wait(3, seconds);
  //stop outtake
  IntMot16.spin(forward, 33, percent);
  //go forward
  RM30();
  LM30();
  wait(1.5, seconds);
  //turn left
  RM30();
  LM0();
  wait(1, seconds);
  //turn right
  LM15();
  RM0();
  wait(0.60, seconds);
  //turn right in place
  LM15();
  RM_15();
  wait(0.60, seconds);
  //turn right
  RM0();
  LM30();
  wait(0.75, seconds);
  //stop
  RM15();
  LM15();
  wait(0.6, seconds);
  //outtake
  IntMot16.spin(reverse, 100, percent);
  wait(1.5, seconds);
  //stop moving
  RM0();
  LM0();
  //outtake
  IntMot16.spin(reverse, 100, percent);
  wait(2, seconds);
  //go backward
  LM_15();
  RM_15();
  wait(1, seconds);
  //go forward fast
  LM0();
  RM0();
  wait(1, seconds);
  //go backward
  LM_15();
  RM_15();
  wait(1, seconds);
  //everything stop
  LM0();
  RM0();
  IntMot16.spin(reverse, 0, percent);

}


int main() {
  Competition.drivercontrol(setSpeed);
  Competition.autonomous(Autonomous);
} 